"""
Test crypto integration
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    import crypto
    print("✅ Crypto module imports successfully")
    
    # Test CoinGecko
    from crypto.coingecko_api import coingecko
    price = coingecko.get_price('bitcoin')
    print(f"✅ Bitcoin price: ${price:,.2f}")
    
    # Test strategies
    from crypto.strategies import crypto_strategies
    print(f"✅ Crypto strategies available")
    
    # Test data manager
    from crypto.data_manager import data_manager
    print(f"✅ Crypto data manager available")
    
    print("\n🎉 CRYPTO INTEGRATION SUCCESSFUL!")
    
except Exception as e:
    print(f"❌ Crypto integration error: {e}")
    import traceback
    traceback.print_exc()
