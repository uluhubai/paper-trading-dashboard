#!/usr/bin/env python3
"""
Test dashboard data loading and formatting
"""

import pandas as pd
import numpy as np
import json
import os
from datetime import datetime

def load_and_format_data():
    """Load data from files and format for dashboard"""
    
    data_dir = 'data'
    portfolio_data = {}
    
    try:
        # 1. Load portfolio history
        portfolio_file = os.path.join(data_dir, 'portfolio_history.csv')
        if os.path.exists(portfolio_file):
            df = pd.read_csv(portfolio_file)
            df['date'] = pd.to_datetime(df['date'])
            
            # Format for dashboard
            portfolio_data['equity_curve'] = df[['date', 'portfolio_value']].copy()
            portfolio_data['equity_curve'].columns = ['timestamp', 'value']
            
            portfolio_data['returns'] = df['daily_return'].tolist()
            
            print(f"✅ Loaded portfolio history: {len(df)} rows")
        
        # 2. Load metrics
        metrics_file = os.path.join(data_dir, 'metrics.json')
        if os.path.exists(metrics_file):
            with open(metrics_file, 'r') as f:
                metrics = json.load(f)
            
            # Format metrics for dashboard
            portfolio_data['metrics'] = {
                'total_return': metrics.get('total_return', 0),
                'sharpe_ratio': metrics.get('sharpe_ratio', 0),
                'max_drawdown': metrics.get('max_drawdown', 0),
                'win_rate': metrics.get('win_rate', 0),
                'volatility': metrics.get('volatility', 0),
                'current_portfolio': metrics.get('current_portfolio', 10000)
            }
            
            print(f"✅ Loaded metrics: {len(metrics)} items")
        
        # 3. Load recent trades
        trades_file = os.path.join(data_dir, 'recent_trades.csv')
        if os.path.exists(trades_file):
            trades_df = pd.read_csv(trades_file)
            trades_df['timestamp'] = pd.to_datetime(trades_df['timestamp'])
            
            # Format trades for dashboard
            portfolio_data['trades'] = trades_df.to_dict('records')
            
            print(f"✅ Loaded trades: {len(trades_df)} trades")
        
        # 4. Create sample positions
        portfolio_data['positions'] = [
            {
                'symbol': 'BTC',
                'quantity': 0.5,
                'avg_price': 45000,
                'current_price': 67321,
                'pnl': (67321 - 45000) * 0.5,
                'pnl_percent': ((67321 / 45000) - 1) * 100
            },
            {
                'symbol': 'ETH',
                'quantity': 3.2,
                'avg_price': 3200,
                'current_price': 3500,
                'pnl': (3500 - 3200) * 3.2,
                'pnl_percent': ((3500 / 3200) - 1) * 100
            }
        ]
        
        portfolio_data['current_prices'] = {
            'BTC': 67321,
            'ETH': 3500,
            'ADA': 0.45
        }
        
        print(f"✅ Created sample positions: {len(portfolio_data['positions'])}")
        
        return portfolio_data
        
    except Exception as e:
        print(f"❌ Error loading data: {e}")
        return None

def test_dashboard_display():
    """Test if dashboard can display the data"""
    
    print("\n🚀 Testing dashboard data display...")
    
    portfolio_data = load_and_format_data()
    
    if not portfolio_data:
        print("❌ Failed to load portfolio data")
        return
    
    print("\n📊 Data structure check:")
    print(f"  - Has metrics: {'metrics' in portfolio_data}")
    print(f"  - Has equity_curve: {'equity_curve' in portfolio_data}")
    print(f"  - Has returns: {'returns' in portfolio_data}")
    print(f"  - Has positions: {'positions' in portfolio_data}")
    print(f"  - Has trades: {'trades' in portfolio_data}")
    
    if 'metrics' in portfolio_data:
        print("\n📈 Sample metrics:")
        for key, value in portfolio_data['metrics'].items():
            if isinstance(value, float):
                if 'return' in key or 'rate' in key:
                    print(f"  - {key}: {value:.2%}")
                elif 'ratio' in key:
                    print(f"  - {key}: {value:.2f}")
                else:
                    print(f"  - {key}: {value:,.2f}")
    
    print("\n✅ Data is properly formatted for dashboard!")
    print("\n🎯 Next steps:")
    print("1. Update dashboard code to load data from files")
    print("2. Restart Streamlit")
    print("3. Refresh browser page")

if __name__ == "__main__":
    print("🔍 Testing Paper Trading Dashboard Data Loading")
    print("=" * 50)
    
    test_dashboard_display()