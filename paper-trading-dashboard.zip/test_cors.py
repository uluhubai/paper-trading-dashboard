#!/usr/bin/env python3
"""
Test CORS headers for Streamlit
"""

import requests

url = "http://100.92.200.109:8501"

try:
    # Test OPTIONS request (CORS preflight)
    print("🔍 Testing CORS headers...")
    response = requests.options(url, timeout=5)
    print(f"OPTIONS Status: {response.status_code}")
    print(f"OPTIONS Headers: {dict(response.headers)}")
    
    # Test GET request
    print("\n🔍 Testing GET request...")
    response = requests.get(url, timeout=5)
    print(f"GET Status: {response.status_code}")
    
    # Check important headers
    headers = response.headers
    print("\n📋 Important Headers:")
    for header in ['Access-Control-Allow-Origin', 'X-Frame-Options', 'Content-Security-Policy']:
        if header in headers:
            print(f"  {header}: {headers[header]}")
        else:
            print(f"  {header}: ❌ NOT SET")
            
except Exception as e:
    print(f"❌ Error: {e}")