"""Crypto Utils Module"""
