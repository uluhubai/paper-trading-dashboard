"""Crypto Data Module"""
