"""Crypto Apis Module"""
